# Amezoneclone
Amazon Clone Website built using HTML, CSS, JavaScript and Node.js. Includes responsive UI, product display sections, cart feature, and backend setup using Node.js.
